﻿namespace Zarządzanie_inwentarzem
{
    partial class DodajSloty
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(DodajSloty));
            System.Windows.Forms.Label slot_IDLabel;
            System.Windows.Forms.Label poj_IDLabel;
            System.Windows.Forms.Label prz_IDLabel;
            this.dataSet = new Zarządzanie_inwentarzem.DataSet();
            this.slotBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.slotTableAdapter = new Zarządzanie_inwentarzem.DataSetTableAdapters.SlotTableAdapter();
            this.tableAdapterManager = new Zarządzanie_inwentarzem.DataSetTableAdapters.TableAdapterManager();
            this.slotBindingNavigator = new System.Windows.Forms.BindingNavigator(this.components);
            this.bindingNavigatorMoveFirstItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMovePreviousItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorPositionItem = new System.Windows.Forms.ToolStripTextBox();
            this.bindingNavigatorCountItem = new System.Windows.Forms.ToolStripLabel();
            this.bindingNavigatorSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorMoveNextItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorMoveLastItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorSeparator2 = new System.Windows.Forms.ToolStripSeparator();
            this.bindingNavigatorAddNewItem = new System.Windows.Forms.ToolStripButton();
            this.bindingNavigatorDeleteItem = new System.Windows.Forms.ToolStripButton();
            this.slotBindingNavigatorSaveItem = new System.Windows.Forms.ToolStripButton();
            this.slot_IDTextBox = new System.Windows.Forms.TextBox();
            this.poj_IDTextBox = new System.Windows.Forms.TextBox();
            this.prz_IDTextBox = new System.Windows.Forms.TextBox();
            slot_IDLabel = new System.Windows.Forms.Label();
            poj_IDLabel = new System.Windows.Forms.Label();
            prz_IDLabel = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBindingNavigator)).BeginInit();
            this.slotBindingNavigator.SuspendLayout();
            this.SuspendLayout();
            // 
            // dataSet
            // 
            this.dataSet.DataSetName = "DataSet";
            this.dataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // slotBindingSource
            // 
            this.slotBindingSource.DataMember = "Slot";
            this.slotBindingSource.DataSource = this.dataSet;
            // 
            // slotTableAdapter
            // 
            this.slotTableAdapter.ClearBeforeFill = true;
            // 
            // tableAdapterManager
            // 
            this.tableAdapterManager.BackupDataSetBeforeUpdate = false;
            this.tableAdapterManager.GraczTableAdapter = null;
            this.tableAdapterManager.PojemnikTableAdapter = null;
            this.tableAdapterManager.PrzedmiotyTableAdapter = null;
            this.tableAdapterManager.SlotTableAdapter = this.slotTableAdapter;
            this.tableAdapterManager.UpdateOrder = Zarządzanie_inwentarzem.DataSetTableAdapters.TableAdapterManager.UpdateOrderOption.InsertUpdateDelete;
            // 
            // slotBindingNavigator
            // 
            this.slotBindingNavigator.AddNewItem = this.bindingNavigatorAddNewItem;
            this.slotBindingNavigator.BindingSource = this.slotBindingSource;
            this.slotBindingNavigator.CountItem = this.bindingNavigatorCountItem;
            this.slotBindingNavigator.DeleteItem = this.bindingNavigatorDeleteItem;
            this.slotBindingNavigator.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.bindingNavigatorMoveFirstItem,
            this.bindingNavigatorMovePreviousItem,
            this.bindingNavigatorSeparator,
            this.bindingNavigatorPositionItem,
            this.bindingNavigatorCountItem,
            this.bindingNavigatorSeparator1,
            this.bindingNavigatorMoveNextItem,
            this.bindingNavigatorMoveLastItem,
            this.bindingNavigatorSeparator2,
            this.bindingNavigatorAddNewItem,
            this.bindingNavigatorDeleteItem,
            this.slotBindingNavigatorSaveItem});
            this.slotBindingNavigator.Location = new System.Drawing.Point(0, 0);
            this.slotBindingNavigator.MoveFirstItem = this.bindingNavigatorMoveFirstItem;
            this.slotBindingNavigator.MoveLastItem = this.bindingNavigatorMoveLastItem;
            this.slotBindingNavigator.MoveNextItem = this.bindingNavigatorMoveNextItem;
            this.slotBindingNavigator.MovePreviousItem = this.bindingNavigatorMovePreviousItem;
            this.slotBindingNavigator.Name = "slotBindingNavigator";
            this.slotBindingNavigator.PositionItem = this.bindingNavigatorPositionItem;
            this.slotBindingNavigator.Size = new System.Drawing.Size(307, 25);
            this.slotBindingNavigator.TabIndex = 0;
            this.slotBindingNavigator.Text = "bindingNavigator1";
            // 
            // bindingNavigatorMoveFirstItem
            // 
            this.bindingNavigatorMoveFirstItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveFirstItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveFirstItem.Image")));
            this.bindingNavigatorMoveFirstItem.Name = "bindingNavigatorMoveFirstItem";
            this.bindingNavigatorMoveFirstItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveFirstItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMoveFirstItem.Text = "Przenieś pierwszy";
            // 
            // bindingNavigatorMovePreviousItem
            // 
            this.bindingNavigatorMovePreviousItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMovePreviousItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMovePreviousItem.Image")));
            this.bindingNavigatorMovePreviousItem.Name = "bindingNavigatorMovePreviousItem";
            this.bindingNavigatorMovePreviousItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMovePreviousItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorMovePreviousItem.Text = "Przenieś poprzedni";
            // 
            // bindingNavigatorSeparator
            // 
            this.bindingNavigatorSeparator.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator.Size = new System.Drawing.Size(6, 25);
            // 
            // bindingNavigatorPositionItem
            // 
            this.bindingNavigatorPositionItem.AccessibleName = "Pozycja";
            this.bindingNavigatorPositionItem.AutoSize = false;
            this.bindingNavigatorPositionItem.Name = "bindingNavigatorPositionItem";
            this.bindingNavigatorPositionItem.Size = new System.Drawing.Size(50, 23);
            this.bindingNavigatorPositionItem.Text = "0";
            this.bindingNavigatorPositionItem.ToolTipText = "Bieżąca pozycja";
            // 
            // bindingNavigatorCountItem
            // 
            this.bindingNavigatorCountItem.Name = "bindingNavigatorCountItem";
            this.bindingNavigatorCountItem.Size = new System.Drawing.Size(29, 15);
            this.bindingNavigatorCountItem.Text = "z {0}";
            this.bindingNavigatorCountItem.ToolTipText = "Suma elementów";
            // 
            // bindingNavigatorSeparator1
            // 
            this.bindingNavigatorSeparator1.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator1.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorMoveNextItem
            // 
            this.bindingNavigatorMoveNextItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveNextItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveNextItem.Image")));
            this.bindingNavigatorMoveNextItem.Name = "bindingNavigatorMoveNextItem";
            this.bindingNavigatorMoveNextItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveNextItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveNextItem.Text = "Przenieś następny";
            // 
            // bindingNavigatorMoveLastItem
            // 
            this.bindingNavigatorMoveLastItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorMoveLastItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorMoveLastItem.Image")));
            this.bindingNavigatorMoveLastItem.Name = "bindingNavigatorMoveLastItem";
            this.bindingNavigatorMoveLastItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorMoveLastItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorMoveLastItem.Text = "Przenieś ostatni";
            // 
            // bindingNavigatorSeparator2
            // 
            this.bindingNavigatorSeparator2.Name = "bindingNavigatorSeparator";
            this.bindingNavigatorSeparator2.Size = new System.Drawing.Size(6, 6);
            // 
            // bindingNavigatorAddNewItem
            // 
            this.bindingNavigatorAddNewItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorAddNewItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorAddNewItem.Image")));
            this.bindingNavigatorAddNewItem.Name = "bindingNavigatorAddNewItem";
            this.bindingNavigatorAddNewItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorAddNewItem.Size = new System.Drawing.Size(23, 22);
            this.bindingNavigatorAddNewItem.Text = "Dodaj nowy";
            // 
            // bindingNavigatorDeleteItem
            // 
            this.bindingNavigatorDeleteItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.bindingNavigatorDeleteItem.Image = ((System.Drawing.Image)(resources.GetObject("bindingNavigatorDeleteItem.Image")));
            this.bindingNavigatorDeleteItem.Name = "bindingNavigatorDeleteItem";
            this.bindingNavigatorDeleteItem.RightToLeftAutoMirrorImage = true;
            this.bindingNavigatorDeleteItem.Size = new System.Drawing.Size(23, 20);
            this.bindingNavigatorDeleteItem.Text = "Usuń";
            // 
            // slotBindingNavigatorSaveItem
            // 
            this.slotBindingNavigatorSaveItem.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.slotBindingNavigatorSaveItem.Image = ((System.Drawing.Image)(resources.GetObject("slotBindingNavigatorSaveItem.Image")));
            this.slotBindingNavigatorSaveItem.Name = "slotBindingNavigatorSaveItem";
            this.slotBindingNavigatorSaveItem.Size = new System.Drawing.Size(23, 23);
            this.slotBindingNavigatorSaveItem.Text = "Zapisz dane";
            this.slotBindingNavigatorSaveItem.Click += new System.EventHandler(this.slotBindingNavigatorSaveItem_Click);
            // 
            // slot_IDLabel
            // 
            slot_IDLabel.AutoSize = true;
            slot_IDLabel.Location = new System.Drawing.Point(139, 102);
            slot_IDLabel.Name = "slot_IDLabel";
            slot_IDLabel.Size = new System.Drawing.Size(42, 13);
            slot_IDLabel.TabIndex = 1;
            slot_IDLabel.Text = "Slot ID:";
            // 
            // slot_IDTextBox
            // 
            this.slot_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.slotBindingSource, "Slot_ID", true));
            this.slot_IDTextBox.Location = new System.Drawing.Point(187, 99);
            this.slot_IDTextBox.Name = "slot_IDTextBox";
            this.slot_IDTextBox.Size = new System.Drawing.Size(100, 20);
            this.slot_IDTextBox.TabIndex = 2;
            // 
            // poj_IDLabel
            // 
            poj_IDLabel.AutoSize = true;
            poj_IDLabel.Location = new System.Drawing.Point(139, 128);
            poj_IDLabel.Name = "poj_IDLabel";
            poj_IDLabel.Size = new System.Drawing.Size(39, 13);
            poj_IDLabel.TabIndex = 3;
            poj_IDLabel.Text = "Poj ID:";
            // 
            // poj_IDTextBox
            // 
            this.poj_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.slotBindingSource, "Poj_ID", true));
            this.poj_IDTextBox.Location = new System.Drawing.Point(187, 125);
            this.poj_IDTextBox.Name = "poj_IDTextBox";
            this.poj_IDTextBox.Size = new System.Drawing.Size(100, 20);
            this.poj_IDTextBox.TabIndex = 4;
            // 
            // prz_IDLabel
            // 
            prz_IDLabel.AutoSize = true;
            prz_IDLabel.Location = new System.Drawing.Point(139, 154);
            prz_IDLabel.Name = "prz_IDLabel";
            prz_IDLabel.Size = new System.Drawing.Size(39, 13);
            prz_IDLabel.TabIndex = 5;
            prz_IDLabel.Text = "Prz ID:";
            // 
            // prz_IDTextBox
            // 
            this.prz_IDTextBox.DataBindings.Add(new System.Windows.Forms.Binding("Text", this.slotBindingSource, "Prz_ID", true));
            this.prz_IDTextBox.Location = new System.Drawing.Point(187, 151);
            this.prz_IDTextBox.Name = "prz_IDTextBox";
            this.prz_IDTextBox.Size = new System.Drawing.Size(100, 20);
            this.prz_IDTextBox.TabIndex = 6;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(307, 262);
            this.Controls.Add(slot_IDLabel);
            this.Controls.Add(this.slot_IDTextBox);
            this.Controls.Add(poj_IDLabel);
            this.Controls.Add(this.poj_IDTextBox);
            this.Controls.Add(prz_IDLabel);
            this.Controls.Add(this.prz_IDTextBox);
            this.Controls.Add(this.slotBindingNavigator);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.slotBindingNavigator)).EndInit();
            this.slotBindingNavigator.ResumeLayout(false);
            this.slotBindingNavigator.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DataSet dataSet;
        private System.Windows.Forms.BindingSource slotBindingSource;
        private DataSetTableAdapters.SlotTableAdapter slotTableAdapter;
        private DataSetTableAdapters.TableAdapterManager tableAdapterManager;
        private System.Windows.Forms.BindingNavigator slotBindingNavigator;
        private System.Windows.Forms.ToolStripButton bindingNavigatorAddNewItem;
        private System.Windows.Forms.ToolStripLabel bindingNavigatorCountItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorDeleteItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveFirstItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMovePreviousItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator;
        private System.Windows.Forms.ToolStripTextBox bindingNavigatorPositionItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator1;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveNextItem;
        private System.Windows.Forms.ToolStripButton bindingNavigatorMoveLastItem;
        private System.Windows.Forms.ToolStripSeparator bindingNavigatorSeparator2;
        private System.Windows.Forms.ToolStripButton slotBindingNavigatorSaveItem;
        private System.Windows.Forms.TextBox slot_IDTextBox;
        private System.Windows.Forms.TextBox poj_IDTextBox;
        private System.Windows.Forms.TextBox prz_IDTextBox;
    }
}