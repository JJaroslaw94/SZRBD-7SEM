﻿namespace Zarządzanie_inwentarzem
{


    public partial class DataSet
    {
    }
}
namespace Zarządzanie_inwentarzem {
    
    
    public partial class DataSet {
    }
}
namespace Zarządzanie_inwentarzem {
    
    
    public partial class DataSet {
    }
}
